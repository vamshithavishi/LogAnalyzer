# Log Analyzer

A command-line tool written in modern C++17 for parsing, searching, filtering,
and summarizing application log files.

## Overview

Log Analyzer reads structured log files (timestamp, level, source, message),
parses each line into a strongly-typed `LogEntry`, and provides search,
filtering, and summary reporting on top of the parsed data. Malformed lines
are skipped and counted rather than crashing the program, so the tool can be
pointed at large, imperfect real-world log files.

## Features

- Parses log lines into structured entries (timestamp, level, source, message)
- Keyword search across log messages
- Filter entries by log level (`INFO`, `WARN`, `ERROR`)
- Summary report with per-level counts
- Graceful handling of malformed lines (skipped + counted, not fatal)
- Clean separation of concerns: parsing, data model, and reporting are
  independent, testable components

## Design

| Component         | Responsibility                                          |
|--------------------|----------------------------------------------------------|
| `LogEntry`         | Immutable data holder for a single parsed log line       |
| `LogParser`        | Reads a file and converts raw lines into `LogEntry` objects |
| `ReportGenerator`  | Searches, filters, and summarizes a collection of entries |

Key decisions:
- **`std::vector<LogEntry>`** for storage — entries are appended once during
  parsing and then scanned repeatedly (search/filter/summary), which favors
  `vector`'s contiguous memory and cache-friendly iteration over
  `list`/`deque`.
- **`enum class LogLevel`** instead of raw strings or ints — gives
  compile-time type safety and avoids silent typos like `"Eror"`.
- **`std::chrono::system_clock::time_point`** for timestamps instead of raw
  strings — enables real date/time comparisons and duration math.
- **`std::optional<LogEntry>`** return type for line-level parsing — makes
  "this line didn't parse" an explicit, type-safe outcome instead of using
  sentinel values or exceptions for expected, recoverable cases.

## Technologies

- C++17
- CMake (3.15+)
- Standard Library only (`<chrono>`, `<optional>`, STL containers) — no
  external dependencies

## Build Instructions

```bash
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
make
```

This produces the `log_analyzer` executable inside `build/`.

## Usage

```bash
./log_analyzer <logfile> [options]

Options:
  --search <keyword>   Show entries containing keyword
  --level <LEVEL>       Show entries matching LEVEL (INFO|WARN|ERROR)
  --summary             Show summary report (default if no option given)
```

### Expected log format

```
YYYY-MM-DD HH:MM:SS LEVEL [Source] Message text
```

Example:
```
2026-07-04 09:01:45 ERROR [DatabaseConnector] Failed to connect to database
```

## Sample Output

```
$ ./log_analyzer logs/sample.log --summary
Parsed 10 entries (1 lines skipped)

===== Log Summary Report =====
Total entries: 10
  INFO:  5
  WARN:  2
  ERROR: 3
===============================
```

```
$ ./log_analyzer logs/sample.log --search "Failed"
Parsed 10 entries (1 lines skipped)

Found 2 entries containing "Failed":
2026-07-04 09:01:45 [ERROR] DatabaseConnector: Failed to connect to database
2026-07-04 09:05:00 [ERROR] PaymentService: Failed to charge card for order 88214
```

## Possible Future Improvements

- Multithreaded parsing for very large log files (split file into chunks,
  parse in parallel, merge results)
- Unit tests (Catch2 or GoogleTest) for `LogParser` and `ReportGenerator`
- Support for additional log formats via a pluggable parser interface
- Export summary reports to JSON/CSV
