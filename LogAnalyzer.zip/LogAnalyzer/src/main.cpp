#include "LogParser.h"
#include "ReportGenerator.h"
#include <iostream>
#include <string>

using namespace loganalyzer;

namespace {

void printUsage(const std::string& programName) {
    std::cerr << "Usage: " << programName << " <logfile> [options]\n"
              << "Options:\n"
              << "  --search <keyword>   Show entries containing keyword\n"
              << "  --level <LEVEL>      Show entries matching LEVEL (INFO|WARN|ERROR)\n"
              << "  --summary            Show summary report (default if no option given)\n";
}

} // namespace

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printUsage(argv[0]);
        return 1;
    }

    std::string logFilePath = argv[1];
    std::string mode = "summary";
    std::string argValue;

    for (int i = 2; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--search" && i + 1 < argc) {
            mode = "search";
            argValue = argv[++i];
        } else if (arg == "--level" && i + 1 < argc) {
            mode = "level";
            argValue = argv[++i];
        } else if (arg == "--summary") {
            mode = "summary";
        }
    }

    LogParser parser;
    std::vector<LogEntry> entries;

    try {
        entries = parser.parseFile(logFilePath);
    } catch (const LogFileException& ex) {
        std::cerr << "Error: " << ex.what() << "\n";
        return 1;
    }

    std::cout << "Parsed " << entries.size() << " entries ("
              << parser.getSkippedLineCount() << " lines skipped)\n\n";

    ReportGenerator report(entries);

    if (mode == "search") {
        auto results = report.searchByKeyword(argValue);
        std::cout << "Found " << results.size() << " entries containing \"" << argValue << "\":\n";
        for (const auto& entry : results) {
            std::cout << entry.toString() << "\n";
        }
    } else if (mode == "level") {
        LogLevel level = logLevelFromString(argValue);
        if (level == LogLevel::UNKNOWN) {
            std::cerr << "Unknown level: " << argValue << " (use INFO, WARN, or ERROR)\n";
            return 1;
        }
        auto results = report.filterByLevel(level);
        std::cout << "Found " << results.size() << " entries at level " << argValue << ":\n";
        for (const auto& entry : results) {
            std::cout << entry.toString() << "\n";
        }
    } else {
        std::cout << report.generateSummary();
    }

    return 0;
}
