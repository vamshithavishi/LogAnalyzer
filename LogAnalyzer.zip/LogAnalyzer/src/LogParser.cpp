#include "LogParser.h"
#include <fstream>
#include <sstream>
#include <iomanip>
#include <ctime>

namespace loganalyzer {

std::vector<LogEntry> LogParser::parseFile(const std::string& filepath) {
    std::ifstream file(filepath);
    if (!file.is_open()) {
        throw LogFileException("Could not open log file: " + filepath);
    }

    skippedLines_ = 0;
    std::vector<LogEntry> entries;
    std::string line;

    while (std::getline(file, line)) {
        if (line.empty()) {
            continue; // blank lines aren't errors, just skip silently
        }

        std::optional<LogEntry> entry = parseLine(line);
        if (entry.has_value()) {
            entries.push_back(std::move(entry.value()));
        } else {
            ++skippedLines_;
        }
    }

    return entries;
}

int LogParser::getSkippedLineCount() const {
    return skippedLines_;
}

// Expected format:
// 2026-07-04 10:32:15 ERROR [DatabaseConnector] Failed to connect
std::optional<LogEntry> LogParser::parseLine(const std::string& line) const {
    std::istringstream iss(line);

    std::string datePart, timePart, levelPart, sourcePart;
    if (!(iss >> datePart >> timePart >> levelPart >> sourcePart)) {
        return std::nullopt; // not enough tokens to be a valid line
    }

    // Source should look like "[Something]"
    if (sourcePart.size() < 2 || sourcePart.front() != '[' || sourcePart.back() != ']') {
        return std::nullopt;
    }
    std::string source = sourcePart.substr(1, sourcePart.size() - 2);

    LogLevel level = logLevelFromString(levelPart);
    if (level == LogLevel::UNKNOWN) {
        return std::nullopt;
    }

    // Everything remaining on the line is the message.
    std::string message;
    std::getline(iss, message);
    if (!message.empty() && message.front() == ' ') {
        message.erase(0, 1);
    }
    if (message.empty()) {
        return std::nullopt;
    }

    // Parse "2026-07-04 10:32:15" into a time_point.
    std::tm tmStruct{};
    std::istringstream timestampStream(datePart + " " + timePart);
    timestampStream >> std::get_time(&tmStruct, "%Y-%m-%d %H:%M:%S");
    if (timestampStream.fail()) {
        return std::nullopt;
    }

    std::time_t timeAsTimeT = timegm(&tmStruct); // UTC, avoids local-timezone surprises
    auto timestamp = std::chrono::system_clock::from_time_t(timeAsTimeT);

    return LogEntry(timestamp, level, source, message);
}

} // namespace loganalyzer
