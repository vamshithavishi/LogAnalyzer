#include "ReportGenerator.h"
#include <algorithm>
#include <sstream>

namespace loganalyzer {

ReportGenerator::ReportGenerator(const std::vector<LogEntry>& entries)
    : entries_(entries) {}

std::vector<LogEntry> ReportGenerator::searchByKeyword(const std::string& keyword) const {
    std::vector<LogEntry> results;
    for (const auto& entry : entries_) {
        if (entry.getMessage().find(keyword) != std::string::npos) {
            results.push_back(entry);
        }
    }
    return results;
}

std::vector<LogEntry> ReportGenerator::filterByLevel(LogLevel level) const {
    std::vector<LogEntry> results;
    for (const auto& entry : entries_) {
        if (entry.getLevel() == level) {
            results.push_back(entry);
        }
    }
    return results;
}

std::unordered_map<LogLevel, int> ReportGenerator::countByLevel() const {
    std::unordered_map<LogLevel, int> counts;
    for (const auto& entry : entries_) {
        counts[entry.getLevel()]++;
    }
    return counts;
}

std::string ReportGenerator::generateSummary() const {
    auto counts = countByLevel();

    std::ostringstream oss;
    oss << "===== Log Summary Report =====\n";
    oss << "Total entries: " << entries_.size() << "\n";
    oss << "  INFO:  " << counts[LogLevel::INFO]  << "\n";
    oss << "  WARN:  " << counts[LogLevel::WARN]  << "\n";
    oss << "  ERROR: " << counts[LogLevel::ERROR] << "\n";
    oss << "===============================\n";
    return oss.str();
}

} // namespace loganalyzer
