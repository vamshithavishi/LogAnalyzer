#include "LogEntry.h"
#include <sstream>
#include <iomanip>
#include <ctime>

namespace loganalyzer {

std::string toString(LogLevel level) {
    switch (level) {
        case LogLevel::INFO:    return "INFO";
        case LogLevel::WARN:    return "WARN";
        case LogLevel::ERROR:   return "ERROR";
        default:                return "UNKNOWN";
    }
}

LogLevel logLevelFromString(const std::string& text) {
    if (text == "INFO")  return LogLevel::INFO;
    if (text == "WARN")  return LogLevel::WARN;
    if (text == "ERROR") return LogLevel::ERROR;
    return LogLevel::UNKNOWN;
}

LogEntry::LogEntry(std::chrono::system_clock::time_point timestamp,
                    LogLevel level,
                    std::string source,
                    std::string message)
    : timestamp_(timestamp),
      level_(level),
      source_(std::move(source)),
      message_(std::move(message)) {}

const std::chrono::system_clock::time_point& LogEntry::getTimestamp() const {
    return timestamp_;
}

LogLevel LogEntry::getLevel() const {
    return level_;
}

const std::string& LogEntry::getSource() const {
    return source_;
}

const std::string& LogEntry::getMessage() const {
    return message_;
}

std::string LogEntry::toString() const {
    std::time_t t = std::chrono::system_clock::to_time_t(timestamp_);
    std::tm tmStruct{};
    localtime_r(&t, &tmStruct);

    std::ostringstream oss;
    oss << std::put_time(&tmStruct, "%Y-%m-%d %H:%M:%S")
        << " [" << loganalyzer::toString(level_) << "] "
        << source_ << ": " << message_;
    return oss.str();
}

} // namespace loganalyzer
