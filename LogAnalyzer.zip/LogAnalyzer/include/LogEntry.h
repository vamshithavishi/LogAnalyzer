#ifndef LOG_ENTRY_H
#define LOG_ENTRY_H

#include <string>
#include <chrono>

namespace loganalyzer {

enum class LogLevel {
    INFO,
    WARN,
    ERROR,
    UNKNOWN
};

// Converts a level to its string form, e.g. LogLevel::WARN -> "WARN"
std::string toString(LogLevel level);

// Converts a string like "ERROR" into the matching LogLevel.
// Returns LogLevel::UNKNOWN if the text doesn't match a known level.
LogLevel logLevelFromString(const std::string& text);

class LogEntry {
public:
    LogEntry(std::chrono::system_clock::time_point timestamp,
              LogLevel level,
              std::string source,
              std::string message);

    const std::chrono::system_clock::time_point& getTimestamp() const;
    LogLevel getLevel() const;
    const std::string& getSource() const;
    const std::string& getMessage() const;

    // Human-readable one-line representation, used by ReportGenerator.
    std::string toString() const;

private:
    std::chrono::system_clock::time_point timestamp_;
    LogLevel level_;
    std::string source_;
    std::string message_;
};

} // namespace loganalyzer

#endif // LOG_ENTRY_H
