#ifndef LOG_PARSER_H
#define LOG_PARSER_H

#include "LogEntry.h"
#include <string>
#include <vector>
#include <optional>
#include <stdexcept>

namespace loganalyzer {

// Thrown when the log file itself can't be opened at all.
class LogFileException : public std::runtime_error {
public:
    explicit LogFileException(const std::string& message)
        : std::runtime_error(message) {}
};

class LogParser {
public:
    // Reads and parses the entire file. Throws LogFileException if the
    // file cannot be opened. Malformed individual lines are skipped
    // (not thrown) and counted instead, since one bad line in a
    // multi-gigabyte log shouldn't abort the whole run.
    std::vector<LogEntry> parseFile(const std::string& filepath);

    // Number of lines that failed to parse in the most recent parseFile call.
    int getSkippedLineCount() const;

private:
    // Attempts to parse a single line into a LogEntry.
    // Returns std::nullopt if the line doesn't match the expected format.
    std::optional<LogEntry> parseLine(const std::string& line) const;

    int skippedLines_ = 0;
};

} // namespace loganalyzer

#endif // LOG_PARSER_H
