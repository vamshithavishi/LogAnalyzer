#ifndef REPORT_GENERATOR_H
#define REPORT_GENERATOR_H

#include "LogEntry.h"
#include <vector>
#include <string>
#include <unordered_map>

namespace loganalyzer {

class ReportGenerator {
public:
    explicit ReportGenerator(const std::vector<LogEntry>& entries);

    // Returns all entries whose message contains the given keyword.
    std::vector<LogEntry> searchByKeyword(const std::string& keyword) const;

    // Returns all entries matching a specific log level.
    std::vector<LogEntry> filterByLevel(LogLevel level) const;

    // Counts how many entries exist for each log level.
    std::unordered_map<LogLevel, int> countByLevel() const;

    // Produces a human-readable summary report as a single string.
    std::string generateSummary() const;

private:
    const std::vector<LogEntry>& entries_;
};

} // namespace loganalyzer

#endif // REPORT_GENERATOR_H
